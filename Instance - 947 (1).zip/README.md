
# Career Compass

This is a web application designed to help users find a fulfilling career path through evidence-based personality assessments.

## Project Structure

- `client/`: Contains the React frontend application (Vite).
- `server/`: Contains the Node.js/Express backend API.
- `data/`: Holds the SQLite database file. This directory should be persistent.
- `dist/`: The build output directory. `public/` for the frontend, `server/` for the backend.

## Development

To run the application in development mode:

1.  **Install dependencies**:
    ```bash
    npm install
    ```
2.  **Set up environment variables**:
    Create a `.env` file in the root directory by copying the `.env.example` file.
    ```bash
    cp .env.example .env
    ```
    Fill in the required values, especially `JWT_SECRET` and `OPENAI_API_KEY`.

3.  **Start the development server**:
    This command runs both the frontend and backend concurrently.
    ```bash
    npm run start
    ```
- The React app will be available at `http://localhost:3000`.
- The Express API will be available at `http://localhost:3001`.

## Deployment

This application is ready to be deployed using Docker or on platforms like Render or Railway.

### Environment Variables

Before deploying, you must set the following environment variables. Create a `.env` file or configure them in your hosting provider's dashboard.

- `PORT`: The port for the production server to listen on (e.g., `4000`).
- `JWT_SECRET`: A strong, unique secret key for signing authentication tokens. **This must be changed for production.**
- `DATA_DIRECTORY`: The absolute path to a persistent directory where the SQLite database will be stored (e.g., `/var/data/career-compass`).
- `OPENAI_API_KEY`: Your API key from OpenAI for the AI Career Advisor feature.

### Deployment Checklist

1.  **Set Environment Variables**: Ensure all required variables are securely configured on your hosting platform.
2.  **Persistent Storage**: Configure a persistent volume or disk and mount it at the path specified in `DATA_DIRECTORY`. This is crucial to prevent data loss on restarts.
3.  **Build Command**: The platform should use `npm run build` to build the application.
4.  **Start Command**: The platform should use `node dist/server/index.js` to run the production server.

### Deploying with Docker

1.  Build the Docker image:
    ```bash
    docker build -t career-compass .
    ```
2.  Run the Docker container, mounting a volume for persistent data and passing environment variables:
    ```bash
    docker run -p 4000:4000 \
      -v /path/on/host/to/data:/home/app/data \
      -e JWT_SECRET="your-production-secret" \
      -e OPENAI_API_KEY="your-openai-key" \
      -e PORT="4000" \
      -e DATA_DIRECTORY="/home/app/data" \
      --name career-compass-app \
      career-compass
    ```
    Replace `/path/on/host/to/data` with a directory on your host machine to store the database.

### Deploying on Render

1.  Create a new "Web Service" on Render and connect your GitHub repository.
2.  Set the **Environment** to "Node".
3.  Set the **Build Command** to `npm run build`.
4.  Set the **Start Command** to `node dist/server/index.js`.
5.  Add a **Persistent Disk**:
    - **Mount Path**: `/home/app/data`
    - **Size**: Choose an appropriate size (e.g., 1 GB).
6.  Add your **Environment Variables** (`JWT_SECRET`, `OPENAI_API_KEY`, `PORT`, `DATA_DIRECTORY=/home/app/data`).
7.  Deploy!
