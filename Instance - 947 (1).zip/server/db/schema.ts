
import type { ColumnType, Generated } from 'kysely';

export interface UsersTable {
  id: Generated<number>;
  email: string;
  password_hash: string;
  created_at: ColumnType<string, string | undefined, never>;
}

export interface AssessmentResultsTable {
  id: Generated<number>;
  user_id: number | null;
  openness: number;
  conscientiousness: number;
  extraversion: number;
  agreeableness: number;
  neuroticism: number;
  created_at: ColumnType<string, string | undefined, never>;
  intellect: number;
  adventurousness: number;
  industriousness: number;
  orderliness: number;
  enthusiasm: number;
  assertiveness: number;
  compassion: number;
  politeness: number;
  withdrawal: number;
  volatility: number;
}

export interface DatabaseSchema {
  users: UsersTable;
  assessment_results: AssessmentResultsTable;
}
