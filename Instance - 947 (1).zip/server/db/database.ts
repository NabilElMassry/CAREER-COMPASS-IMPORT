
import { Kysely, SqliteDialect } from 'kysely';
import Database from 'better-sqlite3';
import type { DatabaseSchema } from './schema';
import path from 'path';

const dataDirectory = process.env.DATA_DIRECTORY || path.join(process.cwd(), 'data');
const dbPath = path.join(dataDirectory, 'database.sqlite');

const sqliteDb = new Database(dbPath);

export const db = new Kysely<DatabaseSchema>({
  dialect: new SqliteDialect({
    database: sqliteDb,
  }),
  log: ['query', 'error'],
});
