
import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../../db/database';
import { AuthRequest } from './auth.middleware';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key';

router.post('/signup', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({ message: 'Email and password are required' });
    return;
  }

  try {
    const existingUser = await db.selectFrom('users').where('email', '=', email).selectAll().executeTakeFirst();
    if (existingUser) {
      res.status(409).json({ message: 'User with this email already exists' });
      return;
    }

    const password_hash = await bcrypt.hash(password, 10);

    const newUser = await db
      .insertInto('users')
      .values({ email, password_hash })
      .returning(['id', 'email'])
      .executeTakeFirstOrThrow();

    const token = jwt.sign({ id: newUser.id, email: newUser.email }, JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({ token, user: { id: newUser.id, email: newUser.email } });
    return;
  } catch (error) {
    console.error('Signup failed:', error);
    res.status(500).json({ message: 'Failed to create user' });
    return;
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({ message: 'Email and password are required' });
    return;
  }

  try {
    const user = await db.selectFrom('users').where('email', '=', email).selectAll().executeTakeFirst();

    if (!user) {
      res.status(401).json({ message: 'Invalid credentials' });
      return;
    }

    const isPasswordValid = await bcrypt.compare(password, user.password_hash);

    if (!isPasswordValid) {
      res.status(401).json({ message: 'Invalid credentials' });
      return;
    }

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });

    res.status(200).json({ token, user: { id: user.id, email: user.email } });
    return;
  } catch (error) {
    console.error('Login failed:', error);
    res.status(500).json({ message: 'Login failed' });
    return;
  }
});

router.get('/me', (req: AuthRequest, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
  
    if (!token) {
      res.status(401).json({ message: 'No token provided' });
      return;
    }
  
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      res.status(200).json({ user: decoded });
      return;
    } catch (error) {
      res.status(401).json({ message: 'Invalid token' });
      return;
    }
});

export default router;
