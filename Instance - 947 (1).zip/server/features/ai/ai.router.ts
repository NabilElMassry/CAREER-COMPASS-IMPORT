
import express from 'express';
import OpenAI from 'openai';
import { db } from '../../db/database';
import { AuthRequest } from '../auth/auth.middleware';

const router = express.Router();

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

router.post('/chat', async (req: AuthRequest, res) => {
  const { message, history, context } = req.body;
  const userId = req.user?.id;

  if (!message) {
    res.status(400).json({ message: 'Message is required' });
    return;
  }

  if (!openai) {
    console.warn('OpenAI API key not configured. Returning a placeholder response.');
    res.status(200).json({
      reply: "The AI advisor is not configured. Please set the OPENAI_API_KEY environment variable.",
    });
    return;
  }

  if (!userId) {
    res.status(401).json({ message: 'Authentication required' });
    return;
  }

  try {
    const latestResult = await db
      .selectFrom('assessment_results')
      .selectAll()
      .where('user_id', '=', userId)
      .orderBy('created_at', 'desc')
      .limit(1)
      .executeTakeFirst();

    let personalityContext = 'The user has not taken a personality assessment yet.';
    if (latestResult) {
      personalityContext = `The user's latest personality assessment scores (out of 50 for traits, 25 for aspects) are:
- Openness: ${latestResult.openness} (Intellect: ${latestResult.intellect}, Adventurousness: ${latestResult.adventurousness})
- Conscientiousness: ${latestResult.conscientiousness} (Industriousness: ${latestResult.industriousness}, Orderliness: ${latestResult.orderliness})
- Extraversion: ${latestResult.extraversion} (Enthusiasm: ${latestResult.enthusiasm}, Assertiveness: ${latestResult.assertiveness})
- Agreeableness: ${latestResult.agreeableness} (Compassion: ${latestResult.compassion}, Politeness: ${latestResult.politeness})
- Neuroticism: ${latestResult.neuroticism} (Withdrawal: ${latestResult.withdrawal}, Volatility: ${latestResult.volatility})`;
    }

    let favoritesContext = '';
    if (context?.favoriteCareers && context.favoriteCareers.length > 0) {
        favoritesContext = `The user has expressed interest in the following careers by marking them as favorites: ${context.favoriteCareers.join(', ')}. Consider these careers when providing advice.`;
    }

    const systemPrompt = `You are Career Compass's AI Advisor. Your role is to provide personalized career advice based on the user's personality profile and stated interests. Be encouraging, insightful, and practical.
${personalityContext}
${favoritesContext}
Keep your responses concise and easy to read. Use markdown for formatting if it helps clarity.`;

    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: 'system', content: systemPrompt },
      ...(history || []),
      { role: 'user', content: message },
    ];

    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: messages,
    });

    const reply = completion.choices[0].message.content;
    res.status(200).json({ reply });
    return;
  } catch (error) {
    console.error('AI chat failed:', error);
    res.status(500).json({ message: 'Failed to get response from AI advisor' });
    return;
  }
});

export default router;
