
import express from 'express';
import { db } from '../../db/database';
import { AuthRequest } from '../auth/auth.middleware';

const router = express.Router();

router.post('/results', async (req: AuthRequest, res) => {
  const { 
    openness, conscientiousness, extraversion, agreeableness, neuroticism,
    intellect, adventurousness, industriousness, orderliness, enthusiasm,
    assertiveness, compassion, politeness, withdrawal, volatility
  } = req.body;
  const userId = req.user?.id || null;

  const scores = {
    openness, conscientiousness, extraversion, agreeableness, neuroticism,
    intellect, adventurousness, industriousness, orderliness, enthusiasm,
    assertiveness, compassion, politeness, withdrawal, volatility
  };

  for (const key in scores) {
    if (typeof scores[key] !== 'number') {
      res.status(400).json({ message: `Invalid score data for ${key}` });
      return;
    }
  }

  try {
    const result = await db
      .insertInto('assessment_results')
      .values({
        user_id: userId,
        ...scores
      })
      .returning('id')
      .executeTakeFirstOrThrow();

    res.status(201).json({ id: result.id });
    return;
  } catch (error) {
    console.error('Failed to save assessment results:', error);
    res.status(500).json({ message: 'Failed to save assessment results' });
    return;
  }
});

router.get('/results/latest', async (req: AuthRequest, res) => {
    const userId = req.user?.id;

    if (!userId) {
        // No user logged in, so no "latest" result to show.
        // The frontend should handle this by showing the "Take Assessment" prompt.
        res.status(404).json({ message: 'No user logged in' });
        return;
    }

    try {
      const latestResult = await db
        .selectFrom('assessment_results')
        .selectAll()
        .where('user_id', '=', userId)
        .orderBy('created_at', 'desc')
        .limit(1)
        .executeTakeFirst();
  
      if (!latestResult) {
        res.status(404).json({ message: 'No assessment results found for this user' });
        return;
      }
  
      res.status(200).json(latestResult);
      return;
    } catch (error) {
      console.error('Failed to fetch latest assessment result:', error);
      res.status(500).json({ message: 'Failed to fetch latest assessment result' });
      return;
    }
  });

router.get('/results/:id', async (req: AuthRequest, res) => {
    const id = parseInt(req.params.id, 10);
    const userId = req.user?.id;

    if (isNaN(id)) {
        res.status(400).json({ message: 'Invalid ID' });
        return;
    }

    try {
        const result = await db
            .selectFrom('assessment_results')
            .selectAll()
            .where('id', '=', id)
            .executeTakeFirst();

        if (!result) {
            res.status(404).json({ message: 'Assessment result not found' });
            return;
        }

        // If the result has a user_id, ensure it matches the logged-in user.
        // Results without a user_id (guest results) can be viewed by anyone with the link.
        if (result.user_id && result.user_id !== userId) {
            res.status(403).json({ message: 'You are not authorized to view this result' });
            return;
        }

        res.status(200).json(result);
        return;
    } catch (error) {
        console.error(`Failed to fetch assessment result with id ${id}:`, error);
        res.status(500).json({ message: 'Failed to fetch assessment result' });
        return;
    }
});

export default router;
