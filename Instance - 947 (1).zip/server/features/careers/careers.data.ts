
import { TraitScores } from './careers.types';

export interface Career {
  title: string;
  description: string;
  profile: TraitScores;
}

// Sample career data with ideal Big Five profiles (scores out of 50)
export const careerData: Career[] = [
  {
    title: 'Software Developer',
    description: 'Designs, develops, and maintains software applications. Requires strong problem-solving skills and attention to detail.',
    profile: {
      openness: 45,
      conscientiousness: 40,
      extraversion: 20,
      agreeableness: 25,
      neuroticism: 20,
    },
  },
  {
    title: 'Graphic Designer',
    description: 'Creates visual concepts to communicate ideas that inspire, inform, or captivate consumers. High creativity is key.',
    profile: {
      openness: 48,
      conscientiousness: 30,
      extraversion: 28,
      agreeableness: 35,
      neuroticism: 25,
    },
  },
  {
    title: 'Sales Manager',
    description: 'Leads a sales team by providing guidance, training, and mentorship. Requires strong social skills and goal-orientation.',
    profile: {
      openness: 35,
      conscientiousness: 42,
      extraversion: 45,
      agreeableness: 38,
      neuroticism: 18,
    },
  },
  {
    title: 'Accountant',
    description: 'Inspects financial records, prepares tax returns, and ensures financial operations run efficiently. Requires high conscientiousness.',
    profile: {
      openness: 20,
      conscientiousness: 48,
      extraversion: 25,
      agreeableness: 30,
      neuroticism: 22,
    },
  },
  {
    title: 'Nurse',
    description: 'Provides direct patient care, administers medications, and offers emotional support. Requires high agreeableness and emotional stability.',
    profile: {
      openness: 30,
      conscientiousness: 40,
      extraversion: 38,
      agreeableness: 47,
      neuroticism: 20,
    },
  },
  {
    title: 'Scientist (Research)',
    description: 'Conducts scientific experiments and analysis to expand knowledge in a particular field. Requires high openness and conscientiousness.',
    profile: {
      openness: 49,
      conscientiousness: 44,
      extraversion: 15,
      agreeableness: 28,
      neuroticism: 20,
    },
  },
  {
    title: 'Marketing Manager',
    description: 'Develops marketing strategies to promote a product or service. Blends creativity with strategic thinking and social engagement.',
    profile: {
      openness: 42,
      conscientiousness: 38,
      extraversion: 43,
      agreeableness: 35,
      neuroticism: 23,
    },
  },
  {
    title: 'Teacher',
    description: 'Educates students at various levels. Requires patience, strong communication skills, and a desire to help others.',
    profile: {
      openness: 38,
      conscientiousness: 39,
      extraversion: 40,
      agreeableness: 45,
      neuroticism: 25,
    },
  },
  {
    title: 'Librarian',
    description: 'Manages library resources and helps patrons find information. A quiet, organized, and service-oriented role.',
    profile: {
      openness: 35,
      conscientiousness: 45,
      extraversion: 20,
      agreeableness: 40,
      neuroticism: 20,
    },
  },
  {
    title: 'Event Planner',
    description: 'Coordinates all aspects of professional meetings and events. A fast-paced role requiring organization and social skills.',
    profile: {
      openness: 40,
      conscientiousness: 43,
      extraversion: 44,
      agreeableness: 37,
      neuroticism: 30,
    },
  },
  {
    title: 'Writer/Author',
    description: 'Creates written content for various media. A highly creative and often solitary profession.',
    profile: {
      openness: 48,
      conscientiousness: 35,
      extraversion: 18,
      agreeableness: 30,
      neuroticism: 32,
    },
  },
  {
    title: 'HR Manager',
    description: 'Oversees employee relations, recruitment, and administrative functions within an organization. People-focused and structured.',
    profile: {
      openness: 30,
      conscientiousness: 41,
      extraversion: 40,
      agreeableness: 42,
      neuroticism: 24,
    },
  },
];
