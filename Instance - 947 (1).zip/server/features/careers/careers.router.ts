
import express from 'express';
import { careerData } from './careers.data';

const router = express.Router();

router.get('/', (req, res) => {
  res.json(careerData);
  return;
});

export default router;
