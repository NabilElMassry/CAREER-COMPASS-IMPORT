
import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import { setupStaticServing } from './static-serve.js';
import assessmentRouter from './features/assessment/assessment.router';
import careersRouter from './features/careers/careers.router';
import authRouter from './features/auth/auth.router';
import aiRouter from './features/ai/ai.router';
import { authenticateToken } from './features/auth/auth.middleware';

const app = express();

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Auth middleware - will attach user to req if token is valid
app.use(authenticateToken);

// API routes
app.use('/api/auth', authRouter);
app.use('/api/assessment', assessmentRouter);
app.use('/api/careers', careersRouter);
app.use('/api/ai', aiRouter);

// example endpoint
// app.get('/api/hello', (req: express.Request, res: express.Response) => {
//   res.json({ message: 'Hello World!' });
// });

// Export a function to start the server
export async function startServer(port) {
  try {
    if (process.env.NODE_ENV === 'production') {
      setupStaticServing(app);
    }
    app.listen(port, () => {
      console.log(`API Server running on port ${port}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

// Start the server directly if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('Starting server...');
  startServer(process.env.PORT || 3001);
}
