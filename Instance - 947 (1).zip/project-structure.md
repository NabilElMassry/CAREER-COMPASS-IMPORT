
# Project Structure

```
.
├── client
│   ├── index.html
│   ├── public
│   │   └── site.webmanifest
│   └── src
│       ├── App.tsx
│       ├── components
│       │   ├── MainLayout.tsx
│       │   └── ui
│       │       ├── button.tsx
│       │       ├── calendar.tsx
│       │       ├── card.tsx
│       │       ├── checkbox.tsx
│       │       ├── command.tsx
│       │       ├── dialog.tsx
│       │       ├── input.tsx
│       │       ├── label.tsx
│       │       ├── popover.tsx
│       │       ├── progress.tsx
│       │       ├── select.tsx
│       │       ├── sheet.tsx
│       │       ├── slider.tsx
│       │       ├── switch.tsx
│       │       ├── table.tsx
│       │       ├── toggle.tsx
│       │       └── tooltip.tsx
│       ├── index.css
│       ├── lib
│       │   └── utils.ts
│       ├── main.tsx
│       └── pages
│           ├── AssessmentPage.tsx
│           ├── DashboardPage.tsx
│           └── NotFoundPage.tsx
├── components.json
├── package.json
├── postcss.config.js
├── scripts
│   └── dev.ts
├── server
│   ├── index.ts
│   └── static-serve.ts
├── tailwind.config.js
├── tsconfig.json
├── tsconfig.server.json
└── vite.config.js
```
