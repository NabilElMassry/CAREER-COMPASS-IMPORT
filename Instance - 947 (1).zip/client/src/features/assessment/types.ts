
export interface TraitScores {
    openness: number;
    conscientiousness: number;
    extraversion: number;
    agreeableness: number;
    neuroticism: number;
    // Aspects
    intellect?: number;
    adventurousness?: number;
    industriousness?: number;
    orderliness?: number;
    enthusiasm?: number;
    assertiveness?: number;
    compassion?: number;
    politeness?: number;
    withdrawal?: number;
    volatility?: number;
}

export interface AssessmentResult extends TraitScores {
    id: number;
    created_at: string;
}
