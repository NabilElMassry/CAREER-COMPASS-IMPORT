
import * as React from 'react';
import { assessmentQuestions, Question, Trait, Aspect } from './questions';
import { TraitScores } from './types';
import { useAuth } from '../auth/AuthContext';

const answerOptions = [
  { value: 1, label: 'Strongly Disagree' },
  { value: 2, label: 'Disagree' },
  { value: 3, label: 'Neutral' },
  { value: 4, label: 'Agree' },
  { value: 5, label: 'Strongly Agree' },
];

export function useAssessment() {
  const { token } = useAuth();
  const [answers, setAnswers] = React.useState<Record<number, number>>({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = React.useState(0);
  const [isCompleted, setIsCompleted] = React.useState(false);

  const totalQuestions = assessmentQuestions.length;
  const currentQuestion = assessmentQuestions[currentQuestionIndex];

  const handleAnswer = (questionIndex: number, value: number) => {
    setAnswers((prev) => ({ ...prev, [questionIndex]: value }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      setIsCompleted(true);
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    }
  };

  const calculateScores = (): TraitScores => {
    const traitScores: Record<Trait, number[]> = { O: [], C: [], E: [], A: [], N: [] };
    const aspectScores: Partial<Record<Aspect, number[]>> = {};

    assessmentQuestions.forEach((q, index) => {
      const answerValue = answers[index];
      if (answerValue === undefined) return;

      const score = q.keyed === 1 ? answerValue : 6 - answerValue;
      traitScores[q.trait].push(score);

      if (!aspectScores[q.aspect]) {
        aspectScores[q.aspect] = [];
      }
      aspectScores[q.aspect]?.push(score);
    });

    const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);

    return {
      openness: sum(traitScores.O),
      conscientiousness: sum(traitScores.C),
      extraversion: sum(traitScores.E),
      agreeableness: sum(traitScores.A),
      neuroticism: sum(traitScores.N),
      // Aspects
      intellect: sum(aspectScores.Intellect || []),
      adventurousness: sum(aspectScores.Adventurousness || []),
      industriousness: sum(aspectScores.Industriousness || []),
      orderliness: sum(aspectScores.Orderliness || []),
      enthusiasm: sum(aspectScores.Enthusiasm || []),
      assertiveness: sum(aspectScores.Assertiveness || []),
      compassion: sum(aspectScores.Compassion || []),
      politeness: sum(aspectScores.Politeness || []),
      withdrawal: sum(aspectScores.Withdrawal || []),
      volatility: sum(aspectScores.Volatility || []),
    };
  };

  const submitAssessment = async () => {
    const scores: TraitScores = calculateScores();
    const headers: HeadersInit = { 'Content-Type': 'application/json' };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch('/api/assessment/results', {
      method: 'POST',
      headers,
      body: JSON.stringify(scores),
    });

    if (!response.ok) {
      throw new Error('Failed to submit assessment');
    }
    return response.json();
  };

  const progress = (Object.keys(answers).length / totalQuestions) * 100;

  return {
    currentQuestion,
    currentQuestionIndex,
    totalQuestions,
    answers,
    isCompleted,
    progress,
    answerOptions,
    handleAnswer,
    handleNext,
    handleBack,
    submitAssessment,
  };
}
