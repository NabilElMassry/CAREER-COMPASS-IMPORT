
export type Trait = 'O' | 'C' | 'E' | 'A' | 'N';
export type Aspect = 'Intellect' | 'Adventurousness' | 'Industriousness' | 'Orderliness' | 'Enthusiasm' | 'Assertiveness' | 'Compassion' | 'Politeness' | 'Withdrawal' | 'Volatility';

export interface Question {
  text: string;
  trait: Trait;
  aspect: Aspect;
  keyed: 1 | -1; // 1 for normal scoring, -1 for reverse scoring
}

export const assessmentQuestions: Question[] = [
  // Openness
  { text: 'I have a rich vocabulary.', trait: 'O', aspect: 'Intellect', keyed: 1 },
  { text: 'I have difficulty understanding abstract ideas.', trait: 'O', aspect: 'Intellect', keyed: -1 },
  { text: 'I have a vivid imagination.', trait: 'O', aspect: 'Adventurousness', keyed: 1 },
  { text: 'I am not interested in abstract ideas.', trait: 'O', aspect: 'Intellect', keyed: -1 },
  { text: 'I have excellent ideas.', trait: 'O', aspect: 'Intellect', keyed: 1 },
  { text: 'I do not have a good imagination.', trait: 'O', aspect: 'Adventurousness', keyed: -1 },
  { text: 'I am quick to understand things.', trait: 'O', aspect: 'Intellect', keyed: 1 },
  { text: 'I love to explore new things.', trait: 'O', aspect: 'Adventurousness', keyed: 1 },
  { text: 'I spend time reflecting on things.', trait: 'O', aspect: 'Intellect', keyed: 1 },
  { text: 'I am full of ideas.', trait: 'O', aspect: 'Adventurousness', keyed: 1 },

  // Conscientiousness
  { text: 'I am always prepared.', trait: 'C', aspect: 'Industriousness', keyed: 1 },
  { text: 'I leave my belongings around.', trait: 'C', aspect: 'Orderliness', keyed: -1 },
  { text: 'I pay attention to details.', trait: 'C', aspect: 'Orderliness', keyed: 1 },
  { text: 'I make a mess of things.', trait: 'C', aspect: 'Orderliness', keyed: -1 },
  { text: 'I get chores done right away.', trait: 'C', aspect: 'Industriousness', keyed: 1 },
  { text: 'I often forget to put things back in their proper place.', trait: 'C', aspect: 'Orderliness', keyed: -1 },
  { text: 'I like order.', trait: 'C', aspect: 'Orderliness', keyed: 1 },
  { text: 'I shirk my duties.', trait: 'C', aspect: 'Industriousness', keyed: -1 },
  { text: 'I follow a schedule.', trait: 'C', aspect: 'Industriousness', keyed: 1 },
  { text: 'I am exacting in my work.', trait: 'C', aspect: 'Industriousness', keyed: 1 },

  // Extraversion
  { text: 'I am the life of the party.', trait: 'E', aspect: 'Enthusiasm', keyed: 1 },
  { text: 'I don\'t talk a lot.', trait: 'E', aspect: 'Assertiveness', keyed: -1 },
  { text: 'I feel comfortable around people.', trait: 'E', aspect: 'Enthusiasm', keyed: 1 },
  { text: 'I keep in the background.', trait: 'E', aspect: 'Assertiveness', keyed: -1 },
  { text: 'I start conversations.', trait: 'E', aspect: 'Enthusiasm', keyed: 1 },
  { text: 'I have little to say.', trait: 'E', aspect: 'Assertiveness', keyed: -1 },
  { text: 'I talk to a lot of different people at parties.', trait: 'E', aspect: 'Enthusiasm', keyed: 1 },
  { text: 'I don\'t like to draw attention to myself.', trait: 'E', aspect: 'Assertiveness', keyed: -1 },
  { text: 'I don\'t mind being the center of attention.', trait: 'E', aspect: 'Enthusiasm', keyed: 1 },
  { text: 'I am quiet around strangers.', trait: 'E', aspect: 'Assertiveness', keyed: -1 },

  // Agreeableness
  { text: 'I am interested in people.', trait: 'A', aspect: 'Compassion', keyed: 1 },
  { text: 'I insult people.', trait: 'A', aspect: 'Politeness', keyed: -1 },
  { text: 'I sympathize with others\' feelings.', trait: 'A', aspect: 'Compassion', keyed: 1 },
  { text: 'I am not interested in other people\'s problems.', trait: 'A', aspect: 'Compassion', keyed: -1 },
  { text: 'I have a soft heart.', trait: 'A', aspect: 'Compassion', keyed: 1 },
  { text: 'I respect authority.', trait: 'A', aspect: 'Politeness', keyed: 1 },
  { text: 'I take time out for others.', trait: 'A', aspect: 'Compassion', keyed: 1 },
  { text: 'I am not really interested in others.', trait: 'A', aspect: 'Politeness', keyed: -1 },
  { text: 'I feel others\' emotions.', trait: 'A', aspect: 'Compassion', keyed: 1 },
  { text: 'I avoid arguments.', trait: 'A', aspect: 'Politeness', keyed: 1 },

  // Neuroticism
  { text: 'I am relaxed most of the time.', trait: 'N', aspect: 'Withdrawal', keyed: -1 },
  { text: 'I get stressed out easily.', trait: 'N', aspect: 'Volatility', keyed: 1 },
  { text: 'I seldom feel blue.', trait: 'N', aspect: 'Withdrawal', keyed: -1 },
  { text: 'I worry about things.', trait: 'N', aspect: 'Withdrawal', keyed: 1 },
  { text: 'I am easily disturbed.', trait: 'N', aspect: 'Volatility', keyed: 1 },
  { text: 'I get upset easily.', trait: 'N', aspect: 'Volatility', keyed: 1 },
  { text: 'I change my mood a lot.', trait: 'N', aspect: 'Volatility', keyed: 1 },
  { text: 'I have frequent mood swings.', trait: 'N', aspect: 'Volatility', keyed: 1 },
  { text: 'I get irritated easily.', trait: 'N', aspect: 'Volatility', keyed: 1 },
  { text: 'I often feel blue.', trait: 'N', aspect: 'Withdrawal', keyed: 1 },
];
