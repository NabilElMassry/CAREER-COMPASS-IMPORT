
export interface EvidencePack {
  id: string;
  title: string;
  category: 'Trait' | 'Career';
  relatedTo: string;
  summary: string;
  content: string[]; // Array of paragraphs
}

export const knowledgeBaseData: EvidencePack[] = [
  {
    id: 'trait-openness',
    title: 'Understanding Openness to Experience',
    category: 'Trait',
    relatedTo: 'Openness',
    summary: 'Openness is one of the five major personality traits. It involves a willingness to try new things and engage in imaginative and intellectual activities.',
    content: [
      'Individuals high in openness are typically described as creative, curious, and adventurous. They are often appreciative of art, emotion, and unusual ideas. They are more likely to hold unconventional beliefs.',
      'In the workplace, high openness can be a great asset in roles that require creative thinking and a flexible attitude. Careers in the arts, design, and scientific research often attract individuals with high scores in this trait.',
      'Conversely, individuals low in openness tend to prefer routine, familiarity, and straightforward thinking. They are often practical and down-to-earth. They may thrive in careers that require adherence to procedures and established systems, such as accounting or administrative roles.',
      'Research from Judge et al. (2002) shows that openness is a valid predictor of training proficiency across many occupations, as those high in this trait are more motivated to learn and have more positive attitudes towards learning experiences.'
    ],
  },
  {
    id: 'trait-conscientiousness',
    title: 'The Importance of Conscientiousness',
    category: 'Trait',
    relatedTo: 'Conscientiousness',
    summary: 'Conscientiousness is characterized by being organized, dependable, and self-disciplined. It is the strongest predictor of job performance across all fields.',
    content: [
      'People high in conscientiousness are diligent, reliable, and have a strong sense of duty. They prefer planned rather than spontaneous behavior and are often seen as responsible and hardworking.',
      'Across a wide range of occupations, conscientiousness is the Big Five trait most consistently correlated with success. A meta-analysis by Barrick & Mount (1991) found that it was a valid predictor of performance for all job groups studied.',
      'This trait is crucial for roles requiring precision, long-term planning, and adherence to rules. Examples include project management, accounting, and law. However, extremely high conscientiousness can sometimes lead to perfectionism and inflexibility.'
    ],
  },
  {
    id: 'trait-agreeableness',
    title: 'The Cooperative Nature of Agreeableness',
    category: 'Trait',
    relatedTo: 'Agreeableness',
    summary: 'Agreeableness reflects a person\'s tendency to be compassionate, cooperative, and trusting. It is a key trait for roles involving teamwork and social harmony.',
    content: [
      'Individuals high in agreeableness are often described as kind, helpful, and considerate. They have an optimistic view of human nature and get along well with others.',
      'This trait is particularly important for careers that involve caring for others or providing service, such as nursing, teaching, and customer support. High agreeableness is a strong predictor of performance in jobs that require teamwork and interpersonal skills.',
      'People low in agreeableness may be more competitive, skeptical, and assertive. While this can be advantageous in certain roles like negotiations or critical analysis, it can also lead to conflict in team-based environments.'
    ],
  },
  {
    id: 'career-software-developer',
    title: 'Personality Profile: Software Developer',
    category: 'Career',
    relatedTo: 'Software Developer',
    summary: 'A look at the typical personality traits that align with a successful career in software development.',
    content: [
      'Software development often attracts individuals with high Openness to Experience. This is because the field is constantly evolving, requiring developers to learn new technologies and creatively solve complex, abstract problems.',
      'High Conscientiousness is also a key predictor of success. Writing clean, efficient, and bug-free code requires significant attention to detail, organization, and discipline.',
      'Extraversion is less critical and often lower in this profession, as much of the work can be solitary and focused. However, communication skills are still vital for collaborating within a team.',
      'Agreeableness levels can vary, but a moderate level is useful for effective teamwork and code reviews. Neuroticism is ideally low, as the ability to handle stress and frustration when debugging is a valuable asset.'
    ],
  },
];
