
import * as React from 'react';
import { TraitScores } from '@/features/assessment/types';
import { Career } from './career-data';

export interface MatchedCareer extends Career {
  fitScore: number;
}

// This hook calculates career matches based on personality scores.
export function useCareerMatcher(userScores: TraitScores | null) {
  const [matchedCareers, setMatchedCareers] = React.useState<MatchedCareer[]>([]);
  const [careerData, setCareerData] = React.useState<Career[]>([]);

  React.useEffect(() => {
    const fetchCareerData = async () => {
      try {
        const response = await fetch('/api/careers');
        if (response.ok) {
          const data = await response.json();
          setCareerData(data);
        }
      } catch (error) {
        console.error('Failed to fetch career data:', error);
      }
    };
    fetchCareerData();
  }, []);

  React.useEffect(() => {
    if (!userScores || careerData.length === 0) {
      setMatchedCareers([]);
      return;
    }

    const calculateFit = (career: Career): MatchedCareer => {
      const traits: (keyof TraitScores)[] = [
        'openness',
        'conscientiousness',
        'extraversion',
        'agreeableness',
        'neuroticism',
      ];
      
      let sumOfSquares = 0;
      for (const trait of traits) {
        const userScore = userScores[trait];
        const careerScore = career.profile[trait];
        sumOfSquares += Math.pow(userScore - careerScore, 2);
      }
      
      // Euclidean distance
      const distance = Math.sqrt(sumOfSquares);
      
      // Normalize the distance to a "fit score" from 0 to 100.
      // Max possible distance is sqrt(5 * 50^2) = ~111.8
      const maxDistance = Math.sqrt(5 * Math.pow(50, 2));
      const fitScore = Math.max(0, 100 - (distance / maxDistance) * 100);
      
      return {
        ...career,
        fitScore: Math.round(fitScore),
      };
    };

    const allCareersWithFit = careerData.map(calculateFit);

    // Sort by fit score in descending order
    allCareersWithFit.sort((a, b) => b.fitScore - a.fitScore);

    // Return the top 10 matches
    setMatchedCareers(allCareersWithFit.slice(0, 10));

  }, [userScores, careerData]);

  return matchedCareers;
}
