
import * as React from 'react';
import { MatchedCareer } from './useCareerMatcher';

interface FavoritesContextType {
  favorites: MatchedCareer[];
  toggleFavorite: (career: MatchedCareer) => void;
  removeFavorite: (careerTitle: string) => void;
}

const FavoritesContext = React.createContext<FavoritesContextType | undefined>(undefined);

export function FavoritesProvider({ children }: { children: React.ReactNode }) {
  const [favorites, setFavorites] = React.useState<MatchedCareer[]>(() => {
    try {
      const item = window.localStorage.getItem('favoriteCareers');
      return item ? JSON.parse(item) : [];
    } catch (error) {
      console.error('Error reading favorites from localStorage', error);
      return [];
    }
  });

  React.useEffect(() => {
    try {
      window.localStorage.setItem('favoriteCareers', JSON.stringify(favorites));
    } catch (error) {
      console.error('Error writing favorites to localStorage', error);
    }
  }, [favorites]);

  const toggleFavorite = (career: MatchedCareer) => {
    setFavorites(prev => {
      const isFavorite = prev.some(fav => fav.title === career.title);
      if (isFavorite) {
        return prev.filter(fav => fav.title !== career.title);
      } else {
        return [...prev, career];
      }
    });
  };

  const removeFavorite = (careerTitle: string) => {
    setFavorites(prev => prev.filter(fav => fav.title !== careerTitle));
  };

  const value = { favorites, toggleFavorite, removeFavorite };

  return (
    <FavoritesContext.Provider value={value}>
      {children}
    </FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const context = React.useContext(FavoritesContext);
  if (context === undefined) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
}
