
import { TraitScores } from '@/features/assessment/types';

export interface Career {
  title: string;
  description: string;
  profile: TraitScores;
}
