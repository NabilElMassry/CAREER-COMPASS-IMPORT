
import * as React from 'react';
import { Routes, Route } from 'react-router-dom';
import MainLayout from './components/MainLayout';
import DashboardPage from './pages/DashboardPage';
import AssessmentPage from './pages/AssessmentPage';
import AssessmentResultsPage from './pages/AssessmentResultsPage';
import RecommendationsPage from './pages/RecommendationsPage';
import KnowledgeBasePage from './pages/KnowledgeBasePage';
import AccountPage from './pages/AccountPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import NotFoundPage from './pages/NotFoundPage';
import ProtectedRoute from './components/ProtectedRoute';
import { useAuth } from './features/auth/AuthContext';
import AiChatPage from './pages/AiChatPage';
import FavoritesPage from './pages/FavoritesPage';
import { FavoritesProvider } from './features/careers/useFavorites';

function App() {
  const { isLoading } = useAuth();

  if (isLoading) {
    return <div className="flex h-screen w-full items-center justify-center">Loading application...</div>;
  }

  return (
    <FavoritesProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        
        {/* Routes that are accessible to guests */}
        <Route element={<MainLayout />}>
          <Route path="assessment" element={<AssessmentPage />} />
          <Route path="assessment/results/:id" element={<AssessmentResultsPage />} />
        </Route>

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<MainLayout />}>
            <Route path="/" element={<DashboardPage />} />
            <Route path="recommendations" element={<RecommendationsPage />} />
            <Route path="knowledge-base" element={<KnowledgeBasePage />} />
            <Route path="account" element={<AccountPage />} />
            <Route path="ai-chat" element={<AiChatPage />} />
            <Route path="favorites" element={<FavoritesPage />} />
          </Route>
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </FavoritesProvider>
  );
}

export default App;
