
import * as React from 'react';
import { Button } from '@/components/ui/button';
import { AssessmentResult } from '@/features/assessment/types';
import { TraitName } from '@/lib/personalityMappings';
import { cn } from '@/lib/utils';

interface CareerFilterProps {
  userResult: AssessmentResult | null;
  activeFilters: TraitName[];
  onFilterChange: (filters: TraitName[]) => void;
}

const traitFilters: { id: TraitName; label: string }[] = [
  { id: 'openness', label: 'Openness' },
  { id: 'conscientiousness', label: 'Conscientiousness' },
  { id: 'extraversion', label: 'Extraversion' },
  { id: 'agreeableness', label: 'Agreeableness' },
  { id: 'neuroticism', label: 'Neuroticism' },
];

function CareerFilter({ userResult, activeFilters, onFilterChange }: CareerFilterProps) {
  const handleToggleFilter = (filter: TraitName) => {
    const newFilters = activeFilters.includes(filter)
      ? activeFilters.filter(f => f !== filter)
      : [...activeFilters, filter];
    onFilterChange(newFilters);
  };

  return (
    <div className="p-4 border rounded-lg bg-card">
      <h4 className="font-semibold mb-2">Filter by Your Traits</h4>
      <p className="text-sm text-muted-foreground mb-4">
        Show careers that align with your strongest personality traits.
      </p>
      <div className="flex flex-wrap gap-2">
        <Button
          variant={activeFilters.includes('top3') ? 'secondary' : 'outline'}
          size="sm"
          onClick={() => handleToggleFilter('top3')}
        >
          Match My Top 3 Traits
        </Button>
        {traitFilters.map(filter => (
          <Button
            key={filter.id}
            variant={activeFilters.includes(filter.id) ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => handleToggleFilter(filter.id)}
            disabled={activeFilters.includes('top3')}
          >
            High {filter.label}
          </Button>
        ))}
      </div>
    </div>
  );
}

export default CareerFilter;
