
import * as React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { getTraitDescription, getAspectDescription, getTraitCategory, TraitName, AspectName } from '@/lib/personalityMappings';

interface AspectScore {
  name: string;
  id: AspectName;
  score: number; // Score out of 25
}

interface PersonalityResultsProps {
  traitName: TraitName;
  score: number; // Score out of 50
  aspectScores?: AspectScore[];
}

function PersonalityResults({ traitName, score, aspectScores }: PersonalityResultsProps) {
  const percentile = (score / 50) * 100;
  const category = getTraitCategory(percentile);
  const interpretation = getTraitDescription(traitName, score);
  const capitalizedTraitName = traitName.charAt(0).toUpperCase() + traitName.slice(1);

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-baseline">
          <CardTitle>{capitalizedTraitName}</CardTitle>
          <span className="text-sm font-semibold text-primary">{category}</span>
        </div>
        <div className="flex items-center gap-4 pt-2">
          <Progress value={percentile} className="flex-1" />
          <span className="font-bold">{Math.round(percentile)}th Percentile</span>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription>{interpretation}</CardDescription>
        {aspectScores && aspectScores.length > 0 && (
          <div className="mt-6 space-y-4">
            <h4 className="font-semibold">Aspects:</h4>
            {aspectScores.map((aspect) => {
              const aspectPercentile = (aspect.score / 25) * 100;
              const aspectInterpretation = getAspectDescription(aspect.id, aspect.score);
              return (
                <div key={aspect.name}>
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-sm font-medium">{aspect.name}</p>
                    <p className="text-sm text-muted-foreground">{Math.round(aspectPercentile)}%</p>
                  </div>
                  <Progress value={aspectPercentile} className="h-1" />
                  <p className="text-xs text-muted-foreground mt-1">{aspectInterpretation}</p>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default PersonalityResults;
