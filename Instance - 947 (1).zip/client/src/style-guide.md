
# Style Guide

This document outlines the color palette and typography settings for the Career Compass application.

## Color Palette

The color palette is defined using CSS variables in `client/src/index.css` and consumed by Tailwind CSS.

### Primary Colors

- **Background**: `hsl(224, 71%, 4%)` - A very dark blue, serving as the main background.
- **Foreground**: `hsl(210, 40%, 98%)` - A light grey for primary text, ensuring high contrast and readability.
- **Card**: `hsl(224, 71%, 10%)` - A slightly lighter dark blue for card backgrounds, creating subtle depth.

### Accent Colors

- **Primary**: `hsl(217.2, 91.2%, 59.8%)` - A vibrant blue used for primary actions, links, and highlights.
- **Secondary**: `hsl(160, 60%, 45%)` - A Phthalocyanine Green used for secondary elements and accents.
- **Destructive**: `hsl(0, 62.8%, 30.6%)` - A deep red for actions that have destructive consequences (e.g., deleting data).

### Neutral & Utility Colors

- **Muted**: `hsl(217.2, 32.6%, 17.5%)` - For muted text, backgrounds, and secondary information.
- **Border**: `hsl(217.2, 32.6%, 17.5%)` - Used for borders on components like cards and inputs.
- **Input**: `hsl(217.2, 32.6%, 17.5%)` - The default background for input fields.
- **Ring**: `hsl(212.7, 91.1%, 50.6%)` - For focus rings to ensure accessibility.

### Chart Colors

A distinct palette for data visualizations:
- `chart-1`: `hsl(220, 70%, 50%)`
- `chart-2`: `hsl(160, 60%, 45%)`
- `chart-3`: `hsl(30, 80%, 55%)`
- `chart-4`: `hsl(280, 65%, 60%)`
- `chart-5`: `hsl(340, 75%, 55%)`

## Typography

The application uses the system's default sans-serif font stack, configured via Tailwind CSS's default theme. Font sizes and weights are managed through Tailwind's utility classes to maintain consistency.

- **Headings**: Use `text-lg`, `text-xl`, `text-2xl`, etc., with `font-semibold` or `font-bold`.
- **Body Text**: Default text size is `text-sm` or `text-base`.
- **Muted Text**: Use `text-muted-foreground` for less important information.

## Responsiveness

The UI is designed to be mobile-first and responsive. Layouts use Flexbox and Grid to adapt to different screen sizes. Components are designed to be usable on both touch and mouse-based devices.
