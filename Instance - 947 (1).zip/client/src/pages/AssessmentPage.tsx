
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useAssessment } from '@/features/assessment/useAssessment';

function AssessmentIntro({ onStart }: { onStart: () => void }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Personality Assessment</CardTitle>
          <CardDescription>
            Discover your traits and how they align with potential career paths. This assessment is based on the Big Five personality model.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p>
              You will be presented with a series of statements. For each one, indicate how well it describes you.
            </p>
            <p>
              The assessment should take about 10-15 minutes to complete. Please answer honestly for the most accurate results.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="ml-auto" onClick={onStart}>Start Assessment</Button>
        </CardFooter>
      </Card>
    </div>
  );
}

function AssessmentQuestionnaire() {
  const navigate = useNavigate();
  const {
    currentQuestion,
    currentQuestionIndex,
    totalQuestions,
    answers,
    progress,
    answerOptions,
    handleAnswer,
    handleNext,
    handleBack,
    submitAssessment,
  } = useAssessment();

  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const result = await submitAssessment();
      navigate(`/assessment/results/${result.id}`);
    } catch (error) {
      console.error(error);
      // TODO: Handle error state in UI
    } finally {
      setIsSubmitting(false);
    }
  };

  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;
  const isAnswered = answers[currentQuestionIndex] !== undefined;

  return (
    <div className="flex flex-1 flex-col items-center justify-center">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <Progress value={progress} className="mb-4" />
          <CardTitle>Question {currentQuestionIndex + 1} of {totalQuestions}</CardTitle>
          <CardDescription className="text-lg pt-2">{currentQuestion.text}</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={answers[currentQuestionIndex]?.toString()}
            onValueChange={(value) => handleAnswer(currentQuestionIndex, parseInt(value))}
            className="space-y-2"
          >
            {answerOptions.map((option) => (
              <div key={option.value} className="flex items-center space-x-2">
                <RadioGroupItem value={option.value.toString()} id={`q${currentQuestionIndex}-o${option.value}`} />
                <Label htmlFor={`q${currentQuestionIndex}-o${option.value}`}>{option.label}</Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter className="justify-between">
          <Button variant="outline" onClick={handleBack} disabled={currentQuestionIndex === 0}>
            Back
          </Button>
          {isLastQuestion ? (
            <Button onClick={handleSubmit} disabled={!isAnswered || isSubmitting}>
              {isSubmitting ? 'Submitting...' : 'Finish & See Results'}
            </Button>
          ) : (
            <Button onClick={handleNext} disabled={!isAnswered}>
              Next
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}

function AssessmentPage() {
  const [isStarted, setIsStarted] = React.useState(false);

  if (!isStarted) {
    return <AssessmentIntro onStart={() => setIsStarted(true)} />;
  }

  return <AssessmentQuestionnaire />;
}

export default AssessmentPage;
