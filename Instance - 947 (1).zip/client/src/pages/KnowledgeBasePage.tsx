
import * as React from 'react';
import { knowledgeBaseData } from '@/features/knowledge-base/knowledge-base-data';
import { EvidencePackCard } from '@/features/knowledge-base/components/EvidencePackCard';

function KnowledgeBasePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Knowledge Base</h1>
        <p className="text-muted-foreground">
          Explore the research behind personality traits and career alignment.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {knowledgeBaseData.map((pack) => (
          <EvidencePackCard key={pack.id} pack={pack} />
        ))}
      </div>
    </div>
  );
}

export default KnowledgeBasePage;
