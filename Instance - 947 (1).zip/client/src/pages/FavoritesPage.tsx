
import * as React from 'react';
import { useFavorites } from '@/features/careers/useFavorites';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { MatchedCareer } from '@/features/careers/useCareerMatcher';

function FavoriteCareerCard({ career }: { career: MatchedCareer }) {
    const { removeFavorite } = useFavorites();
  
    return (
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>{career.title}</CardTitle>
              <CardDescription className="mt-2">{career.description}</CardDescription>
            </div>
            <div className="text-right ml-4 flex-shrink-0 flex flex-col items-end gap-2">
              <div className="text-right">
                  <p className="text-sm text-muted-foreground">Fit Score</p>
                  <p className="text-2xl font-bold text-primary">{career.fitScore}%</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => removeFavorite(career.title)}>
                  <Trash2 className="h-5 w-5 text-destructive" />
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>
    );
  }

function FavoritesPage() {
  const { favorites } = useFavorites();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Favorite Careers</h1>
        <p className="text-muted-foreground">
          A collection of careers you've saved for future reference.
        </p>
      </div>
      {favorites.length > 0 ? (
        <div className="space-y-4">
          {favorites.map((career) => (
            <FavoriteCareerCard key={career.title} career={career} />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-muted-foreground flex flex-col items-center gap-4">
                <Heart className="h-12 w-12 text-muted-foreground/50" />
                <p>You haven't saved any favorite careers yet.</p>
                <p className="text-sm">Click the heart icon on a career to save it here.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default FavoritesPage;
