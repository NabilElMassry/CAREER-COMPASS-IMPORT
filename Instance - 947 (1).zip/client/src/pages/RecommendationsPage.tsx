
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AssessmentResult } from '@/features/assessment/types';
import { useCareerMatcher, MatchedCareer } from '@/features/careers/useCareerMatcher';
import { useAuth } from '@/features/auth/AuthContext';
import { useFavorites } from '@/features/careers/useFavorites';
import { Heart } from 'lucide-react';
import { cn } from '@/lib/utils';
import CareerFilter from '@/components/CareerFilter';
import { TraitName } from '@/lib/personalityMappings';

function CareerMatchCard({ career }: { career: MatchedCareer }) {
  const { favorites, toggleFavorite } = useFavorites();
  const isFavorite = favorites.some(fav => fav.title === career.title);

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{career.title}</CardTitle>
            <CardDescription className="mt-2">{career.description}</CardDescription>
          </div>
          <div className="text-right ml-4 flex-shrink-0 flex flex-col items-end gap-2">
            <div className="text-right">
                <p className="text-sm text-muted-foreground">Fit Score</p>
                <p className="text-2xl font-bold text-primary">{career.fitScore}%</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => toggleFavorite(career)}>
                <Heart className={cn("h-5 w-5", isFavorite ? "fill-red-500 text-red-500" : "text-muted-foreground")} />
            </Button>
          </div>
        </div>
      </CardHeader>
    </Card>
  );
}

function RecommendationsPage() {
  const navigate = useNavigate();
  const { token } = useAuth();
  const [latestResult, setLatestResult] = React.useState<AssessmentResult | null>(null);
  const [loading, setLoading] = React.useState(true);
  const matchedCareers = useCareerMatcher(latestResult);
  const [filteredCareers, setFilteredCareers] = React.useState<MatchedCareer[]>([]);
  const [activeFilters, setActiveFilters] = React.useState<TraitName[]>([]);

  React.useEffect(() => {
    const fetchLatestResult = async () => {
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const response = await fetch('/api/assessment/results/latest', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (response.ok) {
          const data = await response.json();
          setLatestResult(data);
        }
      } catch (error) {
        console.error('Failed to fetch latest assessment result:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchLatestResult();
  }, [token]);

  React.useEffect(() => {
    if (activeFilters.length === 0) {
      setFilteredCareers(matchedCareers);
      return;
    }

    if (!latestResult) {
      setFilteredCareers([]);
      return;
    }

    const getTopTraits = (count: number): TraitName[] => {
        const traits: TraitName[] = ['openness', 'conscientiousness', 'extraversion', 'agreeableness', 'neuroticism'];
        return traits.sort((a, b) => latestResult[b] - latestResult[a]).slice(0, count);
    }

    let traitsToFilter = new Set<TraitName>();
    if (activeFilters.includes('top3')) {
        getTopTraits(3).forEach(trait => traitsToFilter.add(trait));
    } else {
        activeFilters.forEach(filter => traitsToFilter.add(filter));
    }

    const newFilteredCareers = matchedCareers.filter(career => {
        return Array.from(traitsToFilter).every(trait => {
            // Consider a match if the career's score for the trait is high-ish
            return career.profile[trait] > 35;
        });
    });
    setFilteredCareers(newFilteredCareers);

  }, [activeFilters, matchedCareers, latestResult]);


  if (loading) {
    return <div className="flex flex-1 items-center justify-center">Loading recommendations...</div>;
  }

  if (!latestResult) {
    return (
      <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm">
        <div className="flex flex-col items-center gap-1 text-center">
          <h3 className="text-2xl font-bold tracking-tight">No recommendations yet</h3>
          <p className="text-sm text-muted-foreground">
            Take a personality assessment to get your career recommendations.
          </p>
          <Button className="mt-4" onClick={() => navigate('/assessment')}>
            Take Assessment
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Career Recommendations</h1>
        <p className="text-muted-foreground">
          Based on your latest assessment on {new Date(latestResult.created_at).toLocaleDateString()}.
        </p>
      </div>
      <CareerFilter
        userResult={latestResult}
        activeFilters={activeFilters}
        onFilterChange={setActiveFilters}
      />
      <div className="space-y-4">
        {filteredCareers.length > 0 ? (
            filteredCareers.map((career) => (
                <CareerMatchCard key={career.title} career={career} />
            ))
        ) : (
            <Card>
                <CardContent className="pt-6">
                    <p className="text-center text-muted-foreground">No careers match the selected filters.</p>
                </CardContent>
            </Card>
        )}
      </div>
    </div>
  );
}

export default RecommendationsPage;
