
import * as React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AssessmentResult } from '@/features/assessment/types';
import { useCareerMatcher, MatchedCareer } from '@/features/careers/useCareerMatcher';
import { useAuth } from '@/features/auth/AuthContext';
import PersonalityResults from '@/components/PersonalityResults';
import { TraitName, aspectMappings } from '@/lib/personalityMappings';
import { useFavorites } from '@/features/careers/useFavorites';
import { Heart } from 'lucide-react';
import { cn } from '@/lib/utils';

function CareerMatchCard({ career }: { career: MatchedCareer }) {
    const { favorites, toggleFavorite } = useFavorites();
    const isFavorite = favorites.some(fav => fav.title === career.title);

    return (
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>{career.title}</CardTitle>
              <CardDescription className="mt-2">{career.description}</CardDescription>
            </div>
            <div className="text-right ml-4 flex-shrink-0 flex flex-col items-end gap-2">
                <div className="text-right">
                    <p className="text-sm text-muted-foreground">Fit Score</p>
                    <p className="text-2xl font-bold text-primary">{career.fitScore}%</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => toggleFavorite(career)}>
                    <Heart className={cn("h-5 w-5", isFavorite ? "fill-red-500 text-red-500" : "text-muted-foreground")} />
                </Button>
            </div>
          </div>
        </CardHeader>
      </Card>
    );
  }
  
function CareerMatches({ results }: { results: AssessmentResult | null }) {
    const matchedCareers = useCareerMatcher(results);
  
    if (!results || matchedCareers.length === 0) {
      return null;
    }
  
    return (
      <Card>
        <CardHeader>
          <CardTitle>Top Career Matches</CardTitle>
          <CardDescription>
            Based on your personality profile, here are some careers you might find fulfilling.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {matchedCareers.map((career) => (
            <CareerMatchCard key={career.title} career={career} />
          ))}
        </CardContent>
      </Card>
    );
}

function AssessmentResultsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { token } = useAuth();
  const [results, setResults] = React.useState<AssessmentResult | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    const fetchResults = async () => {
      if (!id) {
        setError("No assessment ID provided.");
        setLoading(false);
        return;
      }
      
      const url = `/api/assessment/results/${id}`;
      const headers: HeadersInit = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      try {
        const response = await fetch(url, { headers });
        if (!response.ok) {
          if (response.status === 404) {
            setError("Assessment not found.");
          } else if (response.status === 403) {
            setError("You are not authorized to view these results.");
          } else {
            throw new Error('Failed to fetch results');
          }
          return;
        }
        const data = await response.json();
        setResults(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [id, navigate, token]);

  if (loading) {
    return <div className="flex flex-1 items-center justify-center">Loading results...</div>;
  }

  if (error) {
    return <div className="flex flex-1 items-center justify-center text-destructive">{error}</div>;
  }

  if (!results) {
    return (
        <div className="flex flex-1 items-center justify-center">
            <div className="text-center">
                <p>No assessment results found.</p>
                <Button onClick={() => navigate('/assessment')} className="mt-4">Take Assessment</Button>
            </div>
        </div>
    );
  }

  const traits: TraitName[] = ['openness', 'conscientiousness', 'extraversion', 'agreeableness', 'neuroticism'];

  const getAspectScores = (trait: TraitName) => {
    const aspects = aspectMappings[trait];
    if (!aspects) return [];
    return aspects.map(aspect => ({
        name: aspect.name,
        score: results[aspect.id] || 0,
        id: aspect.id
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
            <h1 className="text-2xl font-bold">Your Personality Assessment Results</h1>
            <p className="text-muted-foreground">
                Completed on {new Date(results.created_at).toLocaleDateString()}
            </p>
        </div>
        <Button onClick={() => navigate('/assessment')}>Take Again</Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
            {traits.map(trait => (
                <PersonalityResults 
                    key={trait} 
                    traitName={trait} 
                    score={results[trait]} 
                    aspectScores={getAspectScores(trait)}
                />
            ))}
        </div>
        <div className="lg:col-start-2">
            <CareerMatches results={results} />
        </div>
      </div>
    </div>
  );
}

export default AssessmentResultsPage;
