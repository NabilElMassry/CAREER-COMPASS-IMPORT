
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { AssessmentResult } from '@/features/assessment/types';
import { useCareerMatcher, MatchedCareer } from '@/features/careers/useCareerMatcher';
import { useAuth } from '@/features/auth/AuthContext';

function TopCareersPreview({ careers }: { careers: MatchedCareer[] }) {
  const navigate = useNavigate();
  return (
    <Card>
      <CardHeader>
        <CardTitle>Top Career Matches</CardTitle>
        <CardDescription>Here are your top 3 matched careers.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {careers.slice(0, 3).map((career) => (
          <div key={career.title} className="flex items-center justify-between p-3 rounded-md hover:bg-muted/50">
            <div>
              <p className="font-semibold">{career.title}</p>
              <p className="text-sm text-muted-foreground line-clamp-2">{career.description}</p>
            </div>
            <div className="text-right ml-4 flex-shrink-0">
              <p className="text-lg font-bold text-primary">{career.fitScore}%</p>
              <p className="text-xs text-muted-foreground">Fit</p>
            </div>
          </div>
        ))}
        <Button variant="outline" className="w-full mt-2" onClick={() => navigate('/recommendations')}>
          View All Recommendations
        </Button>
      </CardContent>
    </Card>
  );
}

function DashboardPage() {
  const navigate = useNavigate();
  const { user, token } = useAuth();
  const [latestResult, setLatestResult] = React.useState<AssessmentResult | null>(null);
  const [loading, setLoading] = React.useState(true);
  const matchedCareers = useCareerMatcher(latestResult);

  const userName = user?.email.split('@')[0];

  React.useEffect(() => {
    const fetchLatestResult = async () => {
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const response = await fetch('/api/assessment/results/latest', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (response.ok) {
          const data = await response.json();
          setLatestResult(data);
        }
      } catch (error) {
        console.error('Failed to fetch latest assessment result:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchLatestResult();
  }, [token]);

  const handleTakeAssessment = () => {
    navigate('/assessment');
  };

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center">
        <p className="text-muted-foreground">Loading dashboard...</p>
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
            <h1 className="text-lg font-semibold md:text-2xl">Dashboard</h1>
            {user && <p className="text-muted-foreground">Welcome back, {userName}!</p>}
        </div>
      </div>
      {latestResult ? (
        <div className="grid gap-6 md:grid-cols-2 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Latest Assessment</CardTitle>
              <CardDescription>
                Completed on {new Date(latestResult.created_at).toLocaleDateString()}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>Your results are ready. View your detailed personality profile and career recommendations.</p>
            </CardContent>
            <CardFooter className="gap-2">
              <Button onClick={() => navigate(`/assessment/results/${latestResult.id}`)}>View Results</Button>
              <Button variant="outline" onClick={handleTakeAssessment}>Take Again</Button>
            </CardFooter>
          </Card>
          <TopCareersPreview careers={matchedCareers} />
        </div>
      ) : (
        <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm mt-6 md:mt-0">
          <div className="flex flex-col items-center gap-2 text-center p-4">
            <h3 className="text-2xl font-bold tracking-tight">Welcome to your Career Compass</h3>
            <p className="text-sm text-muted-foreground">Start by taking an assessment to discover your path.</p>
            <Button className="mt-4" onClick={handleTakeAssessment}>
              Take Assessment
            </Button>
          </div>
        </div>
      )}
    </>
  );
}

export default DashboardPage;
