
export const personalityMappings = {
  traits: {
    openness: {
      exceptionallyLow: "You are extremely practical, conventional, and prefer straightforward, familiar experiences over new or abstract ones. You value tradition and time-tested methods.",
      low: "You tend to be down-to-earth and practical. You likely prefer routine and familiar environments over new and unpredictable ones.",
      average: "You have a healthy balance of appreciating new ideas while also valuing tradition and routine. You are open to some change but are not constantly seeking novelty.",
      high: "You are curious, imaginative, and open to new experiences. You likely enjoy variety, appreciate art and beauty, and are interested in abstract ideas.",
      exceptionallyHigh: "You are exceptionally open, creative, and intellectually curious. You have a deep appreciation for art, a vivid imagination, and a strong desire to learn and explore new, complex, and unconventional ideas.",
    },
    conscientiousness: {
      exceptionallyLow: "You are extremely spontaneous and flexible, strongly disliking schedules and rigid plans. You may struggle with organization and long-term commitments.",
      low: "You tend to be flexible and spontaneous rather than organized and planned. You may prefer a less structured approach to work and life.",
      average: "You are moderately organized and reliable. You can be disciplined when needed but also know when to be flexible and prioritize leisure.",
      high: "You are organized, dependable, and self-disciplined. You take your responsibilities seriously and work diligently to achieve your goals.",
      exceptionallyHigh: "You are exceptionally dutiful, organized, and methodical. You have a powerful sense of responsibility, a strong work ethic, and a drive for perfection.",
    },
    extraversion: {
      exceptionallyLow: "You are extremely introverted and find social situations draining. You strongly prefer solitude or the company of a very small, close-knit group.",
      low: "You are more reserved and introverted. You likely prefer quieter settings and need time alone to recharge your energy after social interaction.",
      average: "You have a balance of extraverted and introverted tendencies. You can enjoy social gatherings but also value your time alone.",
      high: "You are outgoing, energetic, and sociable. You enjoy being around people, feel comfortable in groups, and draw energy from social interaction.",
      exceptionallyHigh: "You are exceptionally extraverted and thrive in social situations. You are assertive, talkative, and constantly seek out engagement and excitement.",
    },
    agreeableness: {
      exceptionallyLow: "You are extremely skeptical, competitive, and direct. You are not afraid to challenge others and may come across as confrontational.",
      low: "You tend to be more competitive than cooperative. You are willing to assert your own interests, which can sometimes lead to conflict.",
      average: "You are a good balance of cooperative and competitive. You can be warm and considerate but are also able to stand up for your own needs.",
      high: "You are compassionate, cooperative, and trusting. You value social harmony and are generally helpful and forgiving.",
      exceptionallyHigh: "You are exceptionally kind, empathetic, and eager to please. You go to great lengths to avoid conflict and help others, sometimes at your own expense.",
    },
    neuroticism: {
      exceptionallyLow: "You are exceptionally calm, emotionally stable, and resilient. It is very rare for you to feel anxious, sad, or stressed.",
      low: "You are generally calm and emotionally stable. You don't react strongly to stress and can handle unexpected challenges without getting too upset.",
      average: "You experience a typical amount of emotional ups and downs. You can handle stress reasonably well but may feel anxious or worried at times.",
      high: "You are sensitive to stress and prone to experiencing negative emotions like anxiety, worry, and sadness. You may be more emotionally reactive than average.",
      exceptionallyHigh: "You are exceptionally sensitive and emotionally reactive. You are prone to frequent and intense feelings of anxiety, worry, and self-doubt.",
    },
  },
  aspects: {
    intellect: {
        low: "You prefer dealing with concrete facts and practical matters over abstract theories.",
        high: "You are intellectually curious and enjoy playing with abstract ideas and theories."
    },
    adventurousness: {
        low: "You prefer familiar routines and experiences.",
        high: "You are eager to have new experiences and try new things."
    },
    industriousness: {
        low: "You are not a workaholic and are easily distracted.",
        high: "You are hard-working, efficient, and have a strong sense of duty."
    },
    orderliness: {
        low: "You are not a perfectionist and are comfortable with a bit of chaos.",
        high: "You are well-organized, tidy, and like to have a plan."
    },
    enthusiasm: {
        low: "You are socially reserved and don't seek out social stimulation.",
        high: "You are outgoing, friendly, and enjoy social gatherings."
    },
    assertiveness: {
        low: "You prefer to let others take the lead.",
        high: "You are self-confident and comfortable taking charge."
    },
    compassion: {
        low: "You are not overly sentimental and can make tough, objective decisions.",
        high: "You are empathetic, kind-hearted, and feel others' pain."
    },
    politeness: {
        low: "You are willing to challenge others and are not afraid of confrontation.",
        high: "You are respectful, polite, and tend to avoid conflict."
    },
    withdrawal: {
        low: "You are not prone to worry or sadness.",
        high: "You are prone to anxiety, depression, and self-consciousness."
    },
    volatility: {
        low: "You are emotionally stable and not easily angered.",
        high: "You can be temperamental and are quick to anger."
    }
  }
};

export type TraitName = keyof typeof personalityMappings.traits;
export type AspectName = keyof typeof personalityMappings.aspects;

export const aspectMappings: Record<TraitName, {id: AspectName, name: string}[]> = {
    openness: [{id: 'intellect', name: 'Intellect'}, {id: 'adventurousness', name: 'Adventurousness'}],
    conscientiousness: [{id: 'industriousness', name: 'Industriousness'}, {id: 'orderliness', name: 'Orderliness'}],
    extraversion: [{id: 'enthusiasm', name: 'Enthusiasm'}, {id: 'assertiveness', name: 'Assertiveness'}],
    agreeableness: [{id: 'compassion', name: 'Compassion'}, {id: 'politeness', name: 'Politeness'}],
    neuroticism: [{id: 'withdrawal', name: 'Withdrawal'}, {id: 'volatility', name: 'Volatility'}],
};

export function getTraitDescription(trait: TraitName, score: number): string {
  const percentile = (score / 50) * 100;
  const descriptions = personalityMappings.traits[trait];

  if (percentile < 10) return descriptions.exceptionallyLow;
  if (percentile < 40) return descriptions.low;
  if (percentile <= 60) return descriptions.average;
  if (percentile <= 90) return descriptions.high;
  return descriptions.exceptionallyHigh;
}

export function getAspectDescription(aspect: AspectName, score: number): string {
    const percentile = (score / 25) * 100; // Aspects are out of 25
    const descriptions = personalityMappings.aspects[aspect];
    return percentile > 50 ? descriptions.high : descriptions.low;
}

export function getTraitCategory(percentile: number): string {
    if (percentile < 10) return "Exceptionally Low";
    if (percentile < 40) return "Low";
    if (percentile <= 60) return "Typical/Average";
    if (percentile <= 90) return "High";
    return "Exceptionally High";
}
